self.__uv$config = {
    prefix: '/astronomy/',
    bare: '/outerspace/',
    encodeUrl: Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler: '/h/algebra.js',
    bundle: '/h/mathematics.js',
    config: '/h/geography.js',
    sw: '/h/english.js',
};
